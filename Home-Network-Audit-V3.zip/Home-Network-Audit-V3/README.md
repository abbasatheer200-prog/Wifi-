# Home Network Audit V3

A **local-only, consent-based** home network diagnostics utility. It is designed to be run on your own computer while connected to your home network—not from a cloud runner.

## Checks
- Detect local IPv4 and interface prefix when supported; otherwise warns that `/24` is a heuristic
- Default gateway and gateway latency/packet loss
- DNS server configuration and a DNS lookup test
- DHCP hints (Windows lease details; NetworkManager information where available)
- Device inventory: IP, reverse hostname, MAC from ARP/neighbour table, rough hostname-based device guess
- Optional common TCP ports on ping-responsive devices **only within the validated private subnet**; warnings for Telnet, FTP, SMB, and RDP exposure
- External connectivity check uses ICMP to two IPs and DNS resolution; no external port scanning
- HTML, JSON, and CSV reports with findings and practical recommendations
- Optional compare against an earlier JSON report to show newly seen and missing IPs

## Requirements
- Python 3.9+
- `ping` and `arp`; Linux prefix/gateway detection uses `ip` when available
- Linux optional `nmcli`/`resolvectl` for additional details
- No third-party Python packages

## Run
```bash
python network_audit.py
```
Optional TCP checks:
```bash
python network_audit.py --port-scan
```
Choose a subnet explicitly (verify your actual LAN first):
```bash
python network_audit.py --subnet 192.168.0.0/24 --port-scan
```
Custom ports:
```bash
python network_audit.py --ports 22,53,80,443,445,8080
```
Skip internet connectivity probes:
```bash
python network_audit.py --skip-connectivity
```
Compare with a previous report:
```bash
python network_audit.py --compare reports/network-audit-YYYYMMDD-HHMMSS.json
```
Reports are written to `reports/` (HTML is convenient to open in a browser).

## Safety limits
- Only RFC1918 private IPv4 ranges are accepted (10/8, 172.16/12, 192.168/16); loopback, link-local, public, and IPv6 targets are rejected.
- Maximum scan size: 1,024 addresses.
- TCP probes run only against hosts discovered by ping inside the selected subnet.
- External connectivity checks are ICMP/DNS only, not port scans.
- Do not use this on networks you do not own or have explicit authorization to test.
- A filtered/closed port is not proof of security; an open port is not automatically a vulnerability.

## Reading findings
The report uses conservative checks. Routers may ignore ping, operating systems may hide DHCP details, and device discovery can miss hosts that block ICMP. Confirm warnings through the router admin page and device settings before changing anything.

### TP-Link Archer AX55 checklist (manual review)
- Router LAN IP and DHCP range should match the home subnet and not conflict with static addresses.
- DHCP server should be enabled if the router is intended to assign addresses automatically.
- Review the DHCP client list against the discovered inventory; unknown devices should be verified, not assumed malicious.
- Use WPA2-AES or WPA3 where supported; avoid WEP and TKIP.
- Keep router firmware current using the official TP-Link support page for the exact hardware revision and region.
- Disable WPS if not needed; use a strong unique router-admin password; consider a guest network for visitors/IoT.
- Verify WAN status and DNS configuration in router admin UI; do not change DNS blindly if ISP or parental-control settings depend on it.

## Test
```bash
python -m unittest discover -s tests -v
```
