import unittest
from unittest.mock import patch
import ipaddress
import network_audit as audit

class ValidationTests(unittest.TestCase):
    def test_private_lan_allowed(self): self.assertEqual(str(audit.validate_subnet("192.168.1.0/24")),"192.168.1.0/24")
    def test_public_rejected(self):
        with self.assertRaises(ValueError): audit.validate_subnet("8.8.8.0/24")
    def test_large_subnet_rejected(self):
        with self.assertRaises(ValueError): audit.validate_subnet("10.0.0.0/16")
    def test_ipv6_rejected(self):
        with self.assertRaises(ValueError): audit.validate_subnet("fd00::/64")
    def test_private_but_bounded_allowed(self): self.assertTrue(audit.validate_subnet("10.0.0.0/22").is_private)

class AssessmentTests(unittest.TestCase):
    def test_dns_failure_finding(self):
        d={"gateway":"192.168.1.1","gateway_ping":{"received":1},"dns_servers":["192.168.1.1"],"dns_test":{"ok":False},"internet_ping":[{"received":1}],"dhcp":{"enabled":"Unknown"}}
        self.assertTrue(any(f["finding"]=="DNS lookup test failed" for f in audit.assess(d)))
    def test_missing_gateway_finding(self):
        d={"gateway":None,"gateway_ping":{"received":0},"dns_servers":[],"dns_test":{"ok":True},"internet_ping":[],"dhcp":{}}
        self.assertGreaterEqual(len(audit.assess(d)),2)
    def test_type_guess(self): self.assertEqual(audit.guess_device_type("android-phone","Unknown"),"phone/tablet")

class ReportTests(unittest.TestCase):
    def test_html_escapes_untrusted_host_names(self):
        d={"created_at":"now","local_ip":"192.168.1.2","subnet":"192.168.1.0/24","gateway":"192.168.1.1","device_count":1,"dns_servers":[],"dhcp":{},"gateway_ping":{},"internet_ping":[],"dns_test":{},"findings":[],"devices":[{"ip":"192.168.1.2","hostname":"<script>alert(1)</script>","mac":"Unknown","device_guess":"Unknown","icmp_responded":True,"open_tcp_ports":[]}]}
        html=audit.render_html(d)
        self.assertNotIn("<script>alert(1)</script>",html)
        self.assertIn("&lt;script&gt;",html)

if __name__=="__main__":unittest.main()

class ScopeTests(unittest.TestCase):
    def test_loopback_rejected(self):
        with self.assertRaises(ValueError): audit.validate_subnet("127.0.0.0/24")
    def test_link_local_rejected(self):
        with self.assertRaises(ValueError): audit.validate_subnet("169.254.0.0/16")
    def test_sensitive_port_finding(self):
        d={"gateway":"192.168.1.1","gateway_ping":{"received":1},"dns_servers":["192.168.1.1"],"dns_test":{"ok":True},"internet_ping":[{"received":1}],"dhcp":{"enabled":"Unknown"},"devices":[{"ip":"192.168.1.10","open_tcp_ports":[{"port":23,"service":"Telnet"}]}]}
        self.assertTrue(any("Telnet" in f["finding"] for f in audit.assess(d)))
