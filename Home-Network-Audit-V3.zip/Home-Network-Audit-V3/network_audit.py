#!/usr/bin/env python3
"""Home Network Audit V3. Local, consent-based diagnostics for a private LAN."""
from __future__ import annotations
import argparse, concurrent.futures, csv, html, ipaddress, json, os, platform, re, shutil, socket, subprocess, sys, time
from datetime import datetime
from pathlib import Path
from typing import Any

COMMON_PORTS = {21:"FTP",22:"SSH",23:"Telnet",53:"DNS",80:"HTTP",135:"MS-RPC",139:"NetBIOS",443:"HTTPS",445:"SMB",554:"RTSP",631:"IPP",3389:"RDP",5000:"HTTP-dev",8080:"HTTP-alt",8443:"HTTPS-alt"}
CONNECTIVITY_TARGETS = ["1.1.1.1", "8.8.8.8"]  # ICMP only; never port-scanned

def run_cmd(args: list[str], timeout: float = 3) -> str:
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout, errors="replace")
        return (p.stdout or "") + (p.stderr or "")
    except (OSError, subprocess.TimeoutExpired):
        return ""

def get_local_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("192.0.2.1", 80)); return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally: s.close()

def get_network(local_ip: str | None = None) -> tuple[ipaddress.IPv4Network, str]:
    """Prefer interface prefix data; fallback /24 and return a human-readable method."""
    local_ip = local_ip or get_local_ip()
    system = platform.system().lower()
    if system == "linux" and shutil.which("ip"):
        text = run_cmd(["ip", "-o", "-f", "inet", "addr", "show"])
        for line in text.splitlines():
            m = re.search(r"\binet\s+(\d+\.\d+\.\d+\.\d+/\d+)", line)
            if m and m.group(1).split("/")[0] == local_ip:
                return ipaddress.ip_network(m.group(1), strict=False), "interface prefix (ip command)"
    if system == "windows":
        text = run_cmd(["ipconfig"])
        blocks = re.split(r"\r?\n\s*\r?\n", text)
        for block in blocks:
            if local_ip in block:
                mask = re.search(r"Subnet Mask[^:]*:\s*(\d+\.\d+\.\d+\.\d+)", block, re.I)
                if mask:
                    try: return ipaddress.ip_network(f"{local_ip}/{mask.group(1)}", strict=False), "ipconfig subnet mask"
                    except ValueError: pass
    if system == "darwin":
        text = run_cmd(["ifconfig"])
        for block in text.split("\n\n"):
            if local_ip in block:
                mask = re.search(r"\bnetmask\s+(0x[0-9a-f]+|\d+\.\d+\.\d+\.\d+)", block, re.I)
                if mask:
                    raw = mask.group(1)
                    try:
                        m = str(ipaddress.IPv4Address(int(raw, 16))) if raw.startswith("0x") else raw
                        return ipaddress.ip_network(f"{local_ip}/{m}", strict=False), "ifconfig subnet mask"
                    except ValueError: pass
    return ipaddress.ip_network(f"{local_ip}/24", strict=False), "fallback /24 heuristic (verify before scanning)"

def validate_subnet(value: str) -> ipaddress.IPv4Network:
    net = ipaddress.ip_network(value, strict=False)
    if not isinstance(net, ipaddress.IPv4Network): raise ValueError("IPv6 scanning is not supported in this version.")
    rfc1918 = [ipaddress.ip_network("10.0.0.0/8"), ipaddress.ip_network("172.16.0.0/12"), ipaddress.ip_network("192.168.0.0/16")]
    if not any(net.subnet_of(allowed) for allowed in rfc1918):
        raise ValueError("Safety stop: only RFC1918 private IPv4 LAN ranges (10/8, 172.16/12, 192.168/16) are allowed; loopback and link-local are excluded.")
    if net.num_addresses > 1024: raise ValueError("Safety stop: subnet exceeds 1,024 addresses. Select a smaller LAN range.")
    return net

def get_gateway() -> str | None:
    system = platform.system().lower()
    if system == "linux" and shutil.which("ip"):
        out = run_cmd(["ip", "route", "show", "default"])
        m = re.search(r"\bvia\s+(\d+\.\d+\.\d+\.\d+)", out); return m.group(1) if m else None
    if system == "windows":
        out = run_cmd(["ipconfig"])
        m = re.search(r"Default Gateway[^:]*:\s*(\d+\.\d+\.\d+\.\d+)", out, re.I); return m.group(1) if m else None
    if system == "darwin":
        out = run_cmd(["route", "-n", "get", "default"])
        m = re.search(r"gateway:\s*(\d+\.\d+\.\d+\.\d+)", out); return m.group(1) if m else None
    return None

def get_dns_servers() -> list[str]:
    system = platform.system().lower(); out = ""
    if system == "windows": out = run_cmd(["ipconfig", "/all"])
    elif system == "darwin": out = run_cmd(["scutil", "--dns"])
    else:
        try: out = Path("/etc/resolv.conf").read_text(errors="replace")
        except OSError: out = ""
        if shutil.which("resolvectl"):
            extra = run_cmd(["resolvectl", "status"])
            if extra: out += "\n" + extra
    found = []
    for m in re.finditer(r"(?:DNS Servers?|nameserver|Server)\s*(?:#\d+)?\s*[: ]\s*(\d+\.\d+\.\d+\.\d+)", out, re.I):
        ip = m.group(1)
        if ip not in found: found.append(ip)
    return found

def get_dhcp_info() -> dict[str, str]:
    system = platform.system().lower()
    if system == "windows":
        out = run_cmd(["ipconfig", "/all"])
        enabled = re.search(r"DHCP Enabled[^:]*:\s*(Yes|No)", out, re.I)
        lease = re.search(r"Lease Obtained[^:]*:\s*(.+)", out, re.I)
        expiry = re.search(r"Lease Expires[^:]*:\s*(.+)", out, re.I)
        return {"enabled": enabled.group(1) if enabled else "Unknown", "lease_obtained": lease.group(1).strip() if lease else "Unknown", "lease_expires": expiry.group(1).strip() if expiry else "Unknown", "source": "ipconfig"}
    if shutil.which("nmcli"):
        out = run_cmd(["nmcli", "-f", "IP4.DHCP4.OPTION", "device", "show"])
        if out.strip(): return {"enabled":"Likely enabled" if "dhcp" in out.lower() else "Unknown", "details":out.strip()[:1500], "source":"nmcli"}
    return {"enabled":"Unknown", "note":"DHCP lease details are not exposed by this platform adapter; inspect router DHCP client list.", "source":"unavailable"}

def ping_once(host: str, timeout: float = 1.0) -> tuple[bool, float | None]:
    system = platform.system().lower()
    if system == "windows": cmd = ["ping", "-n", "1", "-w", str(int(timeout*1000)), host]
    elif system == "darwin": cmd = ["ping", "-c", "1", "-W", str(int(timeout*1000)), host]
    else: cmd = ["ping", "-c", "1", "-W", str(max(1, int(timeout))), host]
    start = time.perf_counter()
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout+2)
        elapsed = (time.perf_counter()-start)*1000
        return p.returncode == 0, elapsed if p.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired): return False, None

def ping_stats(host: str, count: int = 4, timeout: float = 1.0) -> dict[str, Any]:
    results = [ping_once(host, timeout) for _ in range(count)]
    times = [ms for ok, ms in results if ok and ms is not None]
    return {"target":host,"sent":count,"received":len(times),"loss_percent":round((count-len(times))*100/count,1),"min_ms":round(min(times),2) if times else None,"avg_ms":round(sum(times)/len(times),2) if times else None,"max_ms":round(max(times),2) if times else None}

def dns_test() -> dict[str, Any]:
    start=time.perf_counter()
    try:
        ips=sorted({x[4][0] for x in socket.getaddrinfo("example.com",None, family=socket.AF_INET)})
        return {"ok":bool(ips),"hostname":"example.com","resolved_ipv4":ips,"elapsed_ms":round((time.perf_counter()-start)*1000,2)}
    except socket.gaierror as e:
        return {"ok":False,"hostname":"example.com","error":str(e),"elapsed_ms":round((time.perf_counter()-start)*1000,2)}

def parse_arp_table() -> dict[str, str]:
    system=platform.system().lower(); out=run_cmd(["arp","-a"])
    if system=="linux" and shutil.which("ip"): out += "\n" + run_cmd(["ip","neigh"])
    table={}
    for line in out.splitlines():
        ipm=re.search(r"(\d+\.\d+\.\d+\.\d+)",line)
        macm=re.search(r"([0-9a-f]{2}(?:[:-][0-9a-f]{2}){5})",line,re.I)
        if ipm and macm:
            table[ipm.group(1)]=macm.group(1).replace("-",":").upper()
    return table

def hostname_lookup(ip: str) -> str:
    try: return socket.gethostbyaddr(ip)[0]
    except (socket.herror,socket.gaierror,TimeoutError): return "Unknown"

def guess_device_type(hostname: str, mac: str) -> str:
    text=(hostname+" "+mac).lower()
    rules=[("phone/tablet",["iphone","ipad","android","phone","mobile"]),("computer",["desktop","laptop","pc","windows","macbook"]),("printer",["printer","print"]),("router/access point",["router","gateway","ap","wifi"]),("media/IoT",["tv","camera","cam","speaker","nas","echo","chromecast"])]
    for label,words in rules:
        if any(w in text for w in words): return label
    return "Unknown (verify manually)"

def tcp_check(ip: str, ports: list[int], timeout: float=.35) -> list[dict[str, Any]]:
    open_ports=[]
    for port in ports:
        try:
            with socket.create_connection((ip,port),timeout=timeout): open_ports.append({"port":port,"service":COMMON_PORTS.get(port,"custom TCP")})
        except (OSError,TimeoutError): pass
    return open_ports

def inventory(subnet: str, do_ports: bool=False, ports: list[int] | None=None, timeout: float=.8, progress=None) -> list[dict[str, Any]]:
    net=validate_subnet(subnet); addresses=list(net.hosts()); ports=ports or list(COMMON_PORTS)
    arp=parse_arp_table(); rows=[]
    def probe(ip: ipaddress.IPv4Address):
        alive,_=ping_once(str(ip),timeout)
        mac=arp.get(str(ip),"Unknown")
        # Devices already in ARP may be reported even if they suppress ICMP.
        if not alive and mac=="Unknown": return None
        host=hostname_lookup(str(ip))
        return {"ip":str(ip),"hostname":host,"mac":mac,"device_guess":guess_device_type(host,mac),"icmp_responded":alive,"open_tcp_ports":tcp_check(str(ip),ports) if do_ports and alive else []}
    with concurrent.futures.ThreadPoolExecutor(max_workers=40) as pool:
        futures={pool.submit(probe,ip):ip for ip in addresses}; done=0
        for future in concurrent.futures.as_completed(futures):
            done+=1
            try:
                row=future.result()
                if row: rows.append(row)
            except Exception: pass
            if progress: progress(done,len(addresses))
    rows.sort(key=lambda x:ipaddress.ip_address(x["ip"]))
    return rows

def assess(diag: dict[str, Any]) -> list[dict[str, str]]:
    findings=[]
    gw=diag.get("gateway")
    if not gw: findings.append({"severity":"warning","finding":"Default gateway could not be detected","recommendation":"Check router connection and device IP configuration; on the Archer, verify LAN DHCP settings."})
    elif not diag.get("gateway_ping",{}).get("received",0): findings.append({"severity":"warning","finding":"Gateway did not respond to ICMP","recommendation":"Confirm gateway IP and Wi-Fi/LAN connection. Some routers block ping; verify by opening router admin page before treating this as a fault."})
    if not diag.get("dns_servers"): findings.append({"severity":"warning","finding":"DNS servers were not detected","recommendation":"Check DHCP DNS settings on the router or manual DNS settings on the device."})
    if not diag.get("dns_test",{}).get("ok"): findings.append({"severity":"error","finding":"DNS lookup test failed","recommendation":"Restart router and device; check router DNS settings. If using custom DNS, temporarily test automatic DNS or a trusted resolver."})
    if not any(x.get("received",0)>0 for x in diag.get("internet_ping",[])): findings.append({"severity":"warning","finding":"External ICMP tests received no replies","recommendation":"ICMP may be blocked; DNS test and browser connectivity are additional checks. If all fail, inspect WAN status and ISP connection."})
    if diag.get("dhcp",{}).get("enabled")=="No": findings.append({"severity":"info","finding":"DHCP appears disabled on this device","recommendation":"If this device should use automatic addressing, enable DHCP client/automatic IP in its network settings. Router DHCP server is a separate setting."})
    for device in diag.get("devices", []):
        opened={p.get("port") for p in device.get("open_tcp_ports", [])}
        sensitive=[(23,"Telnet"),(21,"FTP"),(445,"SMB"),(3389,"RDP")]
        for port,label in sensitive:
            if port in opened:
                findings.append({"severity":"warning","finding":f"{label} (TCP {port}) is open on {device.get('ip')}","recommendation":f"Verify that {label} is required and trusted on this device. Disable it or restrict access in device settings/firewall if unused; an open port alone is not proof of vulnerability."})
    if not findings: findings.append({"severity":"info","finding":"No obvious issue detected by the basic checks","recommendation":"This is not a full security assessment. Review router firmware, Wi-Fi encryption, guest network, admin password, and connected-device list."})
    return findings

def run_audit(subnet: str|None=None, port_scan: bool=False, ports: list[int]|None=None, do_external: bool=True, timeout: float=.8, progress=None) -> dict[str, Any]:
    local=get_local_ip(); net,method=get_network(local) if subnet is None else (validate_subnet(subnet),"user-specified subnet")
    validate_subnet(str(net))
    gateway=get_gateway(); dns=get_dns_servers(); dhcp=get_dhcp_info()
    diag={"local_ip":local,"subnet":str(net),"subnet_method":method,"gateway":gateway,"dns_servers":dns,"dhcp":dhcp,
          "gateway_ping":ping_stats(gateway) if gateway else {"target":None,"sent":0,"received":0,"loss_percent":None},
          "internet_ping":[ping_stats(t,2) for t in CONNECTIVITY_TARGETS] if do_external else [],"dns_test":dns_test() if do_external else {"ok":None,"skipped":True}}
    devices=inventory(str(net),port_scan,ports,timeout,progress)
    diag["devices"]=devices;diag["device_count"]=len(devices);diag["findings"]=assess(diag)
    diag["created_at"]=datetime.now().astimezone().isoformat(timespec="seconds")
    diag["scope_note"]="Only the validated private IPv4 subnet was ping-discovered; TCP checks are limited to responding hosts inside that subnet. External targets were ICMP/DNS connectivity tests only."
    return diag

def write_reports(data: dict[str, Any], outdir: str="reports") -> list[Path]:
    folder=Path(outdir);folder.mkdir(parents=True,exist_ok=True);stamp=datetime.now().strftime("%Y%m%d-%H%M%S")
    jp=folder/f"network-audit-{stamp}.json"; cp=folder/f"devices-{stamp}.csv"; hp=folder/f"network-audit-{stamp}.html"
    jp.write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding="utf-8")
    with cp.open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=["ip","hostname","mac","device_guess","icmp_responded","open_ports"]);w.writeheader()
        for d in data.get("devices",[]): w.writerow({**d,"open_ports":"; ".join(f"{p['port']} {p['service']}" for p in d.get("open_tcp_ports",[]))})
    hp.write_text(render_html(data),encoding="utf-8")
    return [jp,cp,hp]

def render_html(data: dict[str, Any]) -> str:
    esc=lambda x:html.escape(str(x))
    devices=[]
    for d in data.get("devices",[]):
        ports=", ".join(f"{p['port']}/{p['service']}" for p in d.get("open_tcp_ports",[])) or "—"
        devices.append("<tr>"+"".join(f"<td>{esc(v)}</td>" for v in [d.get("ip"),d.get("hostname"),d.get("mac"),d.get("device_guess"),"Yes" if d.get("icmp_responded") else "No",ports])+"</tr>")
    findings="".join(f"<li><strong>{esc(f['severity'].upper())}:</strong> {esc(f['finding'])}<br>{esc(f['recommendation'])}</li>" for f in data.get("findings",[]))
    return f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Home Network Audit</title><style>body{{font:16px system-ui;max-width:1100px;margin:2rem auto;padding:0 1rem;color:#17202a}}table{{border-collapse:collapse;width:100%;overflow:auto}}th,td{{border:1px solid #ddd;padding:.55rem;text-align:left}}th{{background:#eef2f5}}.summary{{display:flex;gap:1rem;flex-wrap:wrap}}.card{{padding:1rem;border:1px solid #ddd;border-radius:10px}}li{{margin:.7rem 0}}</style><h1>Home Network Audit</h1><p>Created: {esc(data.get('created_at'))}</p><div class="summary"><div class="card">Local IP: {esc(data.get('local_ip'))}</div><div class="card">Subnet: {esc(data.get('subnet'))}</div><div class="card">Gateway: {esc(data.get('gateway') or 'Unknown')}</div><div class="card">Devices: {esc(data.get('device_count',0))}</div></div><h2>Diagnostics</h2><pre>{esc(json.dumps({k:data.get(k) for k in ['dns_servers','dhcp','gateway_ping','internet_ping','dns_test']},indent=2))}</pre><h2>Findings & recommendations</h2><ul>{findings}</ul><h2>Device inventory</h2><table><thead><tr><th>IP</th><th>Hostname</th><th>MAC</th><th>Guess</th><th>Ping</th><th>TCP ports</th></tr></thead><tbody>{''.join(devices)}</tbody></table><p><small>Local network inventory, not a vulnerability scan. Use only networks you own or are authorized to inspect.</small></p></html>'''

def main() -> int:
    p=argparse.ArgumentParser(description="Audit your own private LAN: inventory, gateway, DNS, DHCP, latency, packet loss, and optional TCP ports.")
    p.add_argument("--subnet",help="Private IPv4 subnet, e.g. 192.168.1.0/24; default detects interface prefix where possible")
    p.add_argument("--port-scan",action="store_true",help="Check common TCP ports on ping-responsive LAN hosts")
    p.add_argument("--ports",help="Comma-separated TCP ports; implies --port-scan")
    p.add_argument("--skip-connectivity",action="store_true",help="Skip external ping and DNS connectivity tests")
    p.add_argument("--compare",help="Compare discovered devices with a previous JSON audit report")
    p.add_argument("--timeout",type=float,default=.8,help="Per-host ping timeout (seconds)")
    p.add_argument("--output",default="reports",help="Report directory")
    args=p.parse_args()
    if args.timeout<=0 or args.timeout>5: p.error("--timeout must be > 0 and <= 5 seconds")
    ports=list(COMMON_PORTS)
    if args.ports:
        try: ports=sorted(set(int(x.strip()) for x in args.ports.split(",")))
        except ValueError: p.error("--ports must be comma-separated numbers")
        if not ports or any(x<1 or x>65535 for x in ports): p.error("Ports must be 1–65535")
    subnet=args.subnet
    if not subnet:
        net,method=get_network();subnet=str(net);print(f"Detected subnet: {subnet} ({method})")
        if "fallback" in method: print("WARNING: Prefix is guessed. Verify it before scanning.")
    try: validate_subnet(subnet)
    except ValueError as e: p.error(str(e))
    print(f"Audit scope: {subnet}. Only private LAN hosts are inventoried.")
    if args.port_scan or args.ports: print("TCP checks enabled; limited to discovered hosts in the selected LAN.")
    data=run_audit(subnet,args.port_scan or bool(args.ports),ports,not args.skip_connectivity,args.timeout,lambda d,t:print(f"\rDiscovery: {d}/{t}",end="",flush=True))
    if args.compare:
        try:
            previous=json.loads(Path(args.compare).read_text(encoding="utf-8"))
            old={d.get("ip"):d for d in previous.get("devices",[])}; new={d.get("ip"):d for d in data.get("devices",[])}
            data["comparison"]={"previous_report":args.compare,"new_ips":sorted(set(new)-set(old),key=ipaddress.ip_address),"missing_ips":sorted(set(old)-set(new),key=ipaddress.ip_address)}
        except (OSError,json.JSONDecodeError,TypeError) as e: p.error(f"Could not read comparison report: {e}")
    print(f"\nDevices found: {data['device_count']}")
    if data.get("comparison"):
        print("New since previous report:", ", ".join(data["comparison"]["new_ips"]) or "none")
        print("Not seen this scan:", ", ".join(data["comparison"]["missing_ips"]) or "none")
    for d in data["devices"]: print(f"{d['ip']:15} {d['hostname'][:25]:25} {d['mac']:17} {d['device_guess']}")
    print("\nFindings:")
    for f in data["findings"]: print(f"- {f['severity'].upper()}: {f['finding']} — {f['recommendation']}")
    paths=write_reports(data,args.output);print("\nReports:");[print(f"- {x}") for x in paths]
    return 0
if __name__=="__main__": sys.exit(main())
